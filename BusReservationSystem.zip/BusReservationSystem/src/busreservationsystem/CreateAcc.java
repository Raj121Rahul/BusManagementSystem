package busreservationsystem;
import javax.swing.JFrame;

public class CreateAcc extends JFrame{
    CreateAcc(){
        CreateUses au=new CreateUses();
        this.add(au);
    }
}
