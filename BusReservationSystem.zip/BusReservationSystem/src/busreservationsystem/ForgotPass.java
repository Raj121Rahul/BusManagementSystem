package busreservationsystem;
import javax.swing.JFrame;

public class ForgotPass extends JFrame{
    ForgotPass(){
        ForgotPass_P fp=new ForgotPass_P();
        this.add(fp);
    }
}
